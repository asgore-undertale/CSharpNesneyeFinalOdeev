﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final_Odev_library
{
    public class Book : LibraryItem
    {
        private int _pageCount;

        public Book(string title, string author, int pageCount)
            : base(title, author, "Book")
        {
            if (pageCount <= 0)
                throw new ArgumentException("Page count must be greater than zero.");
            _pageCount = pageCount;
        }

        public override string DisplayDetails() =>
            $"[Book] ID: {Id}, Title: {Title}, Author: {Author}, Pages: {_pageCount}, Checked Out: {IsCheckedOut}";

        public override string ToCsv() => $"{Id},{ItemType},{Title},{Author},{_pageCount},{IsCheckedOut}";
    }
}
