﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final_Odev_library
{
    public class DVD : LibraryItem
    {
        private double _duration;

        public DVD(string title, string author, double duration)
            : base(title, author, "DVD")
        {
            if (duration <= 0)
                throw new ArgumentException("Duration must be greater than zero.");
            _duration = duration;
        }

        public override string DisplayDetails() =>
            $"[DVD] ID: {Id}, Title: {Title}, Author: {Author}, Duration: {_duration} minutes, Checked Out: {IsCheckedOut}";

        public override string ToCsv() => $"{Id},{ItemType},{Title},{Author},{_duration},{IsCheckedOut}";
    }
}
