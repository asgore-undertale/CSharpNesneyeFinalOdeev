﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final_Odev_library
{
    public interface ILibraryItemFactory
    {
        LibraryItem CreateLibraryItem(string itemType, string title, string author, string[] additionalData, bool isCheckedOut);
    }

    public class LibraryItemFactory : ILibraryItemFactory
    {
        public LibraryItem CreateLibraryItem(string itemType, string title, string author, string[] additionalData, bool isCheckedOut)
        {
            if (itemType == "Book")
            {
                int pageCount = int.Parse(additionalData[0]);
                var book = new Book(title, author, pageCount);
                if (isCheckedOut) book.CheckOut();
                return book;
            }
            else if (itemType == "DVD")
            {
                double duration = double.Parse(additionalData[0]);
                var dvd = new DVD(title, author, duration);
                if (isCheckedOut) dvd.CheckOut();
                return dvd;
            }
            else
            {
                throw new ArgumentException("Unknown item type.");
            }
        }
    }

    public abstract class LibraryItem
    {
        public Guid Id { get; protected set; } = Guid.NewGuid();
        public string Title { get; protected set; }
        public string Author { get; protected set; }
        public string ItemType { get; protected set; }
        public bool IsCheckedOut { get; protected set; }

        public LibraryItem(string title, string author, string itemType)
        {
            Title = title;
            Author = author;
            ItemType = itemType;
            IsCheckedOut = false;
        }

        public abstract string DisplayDetails();
        public virtual void CheckOut() {
            if (IsCheckedOut)
                throw new InvalidOperationException("Item is already checked out.");
            IsCheckedOut = true;
        }
        public virtual void Return() {
            if (!IsCheckedOut)
                throw new InvalidOperationException("Item is not checked out.");
            IsCheckedOut = false;
        }
        public virtual string ToCsv()
        {
            return $"{Id},{ItemType},{Title},{Author},{IsCheckedOut}";
        }
    }

}
