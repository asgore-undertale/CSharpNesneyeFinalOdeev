﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final_Odev_library
{
    public class Library
    {
        private List<LibraryItem> _items = new List<LibraryItem>();
        private readonly string _filePath;

        private readonly ILibraryItemFactory _itemFactory;

        public Library(string filePath, ILibraryItemFactory itemFactory)
        {
            _filePath = filePath;
            _itemFactory = itemFactory;
            LoadFromCsv();
        }


        public void AddItem(LibraryItem item)
        {
            _items.Add(item);
            SaveToCsv();
        }

        public void DeleteItem(Guid id)
        {
            var item = FindItemById(id);
            _items.Remove(item);
            SaveToCsv();
        }

        public void ModifyItem(Guid id, LibraryItem newItem)
        {
            DeleteItem(id);
            AddItem(newItem);
        }

        public string ListItems()
        {
            var details = _items.Select(item => item.DisplayDetails()).ToList();
            return string.Join("\n", details);
        }

        public LibraryItem FindItemById(Guid id)
        {
            var item = _items.FirstOrDefault(i => i.Id == id);
            if (item == null)
                throw new ArgumentException("Item not found.");
            return item;
        }

        private void LoadFromCsv()
        {
            if (!File.Exists(_filePath)) return;

            foreach (var line in File.ReadAllLines(_filePath))
            {
                var parts = line.Split(',');
                if (parts.Length < 6) continue;

                var id = Guid.Parse(parts[0]);
                var itemType = parts[1];
                var title = parts[2];
                var author = parts[3];
                var additionalData = new[] { parts[4] }; // Additional data (e.g., page count or duration)
                var isCheckedOut = bool.Parse(parts[5]);

                var item = _itemFactory.CreateLibraryItem(itemType, title, author, additionalData, isCheckedOut);
                item.GetType().GetProperty("Id").SetValue(item, id); // Set the ID explicitly
                _items.Add(item);
            }
        }


        private void SaveToCsv()
        {
            var lines = _items.Select(item => item.ToCsv());
            File.WriteAllLines(_filePath, lines);
        }
    }
}
