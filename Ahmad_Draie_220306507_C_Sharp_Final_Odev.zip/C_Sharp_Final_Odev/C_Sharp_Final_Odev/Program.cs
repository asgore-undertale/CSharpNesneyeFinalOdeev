﻿using C_Sharp_Final_Odev_library;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace C_Sharp_Final_Odev
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to the Library System CLI!");
            Console.WriteLine("With an awesome data persistence feature!!! \\(^o^)/ ");

            string filePath = "library.csv";
            LibraryItemFactory factory = new LibraryItemFactory();
            Library library = new Library(filePath, factory);

            while (true)
            {
                Console.WriteLine("\nMenu:");
                Console.WriteLine("1. Add Item");
                Console.WriteLine("2. List Items");
                Console.WriteLine("3. Modify Item");
                Console.WriteLine("4. Delete Item");
                Console.WriteLine("5. Check Out Item");
                Console.WriteLine("6. Return Item");
                Console.WriteLine("7. Exit");

                Console.Write("Select an option (1-7): ");
                string choice = Console.ReadLine();

                try
                {
                    switch (choice)
                    {
                        case "1":
                            AddItem(library);
                            break;
                        case "2":
                            ListItems(library);
                            break;
                        case "3":
                            ModifyItem(library);
                            break;
                        case "4":
                            DeleteItem(library);
                            break;
                        case "5":
                            CheckOutItem(library);
                            break;
                        case "6":
                            ReturnItem(library);
                            break;
                        case "7":
                            Console.WriteLine("Exiting... Goodbye!");
                            return;
                        default:
                            Console.WriteLine("Invalid option. Please try again.");
                            break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Error: {ex.Message}");
                }
            }
        }

        static void AddItem(Library library)
        {
            Console.Write("Enter item type (Book/DVD): ");
            string itemType = Console.ReadLine();

            Console.Write("Enter title: ");
            string title = Console.ReadLine();

            Console.Write("Enter author: ");
            string author = Console.ReadLine();

            if (itemType.Equals("Book", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Enter page count: ");
                int pageCount = int.Parse(Console.ReadLine());

                var book = new Book(title, author, pageCount);
                library.AddItem(book);
                Console.WriteLine("Book added successfully.");
            }
            else if (itemType.Equals("DVD", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Enter duration (in minutes): ");
                double duration = double.Parse(Console.ReadLine());

                var dvd = new DVD(title, author, duration);
                library.AddItem(dvd);
                Console.WriteLine("DVD added successfully.");
            }
            else
            {
                Console.WriteLine("Invalid item type.");
            }
        }

        static void ListItems(Library library)
        {
            string items = library.ListItems();
            if (string.IsNullOrWhiteSpace(items))
            {
                Console.WriteLine("No items in the library.");
            }
            else
            {
                Console.WriteLine("\nLibrary Items:");
                Console.WriteLine(items);
            }
        }

        static void ModifyItem(Library library)
        {
            Console.Write("Enter the ID of the item to modify: ");
            Guid id = Guid.Parse(Console.ReadLine());

            Console.Write("Enter new title: ");
            string newTitle = Console.ReadLine();

            Console.Write("Enter new author: ");
            string newAuthor = Console.ReadLine();

            Console.Write("Enter item type (Book/DVD): ");
            string itemType = Console.ReadLine();

            if (itemType.Equals("Book", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Enter new page count: ");
                int newPageCount = int.Parse(Console.ReadLine());

                var newBook = new Book(newTitle, newAuthor, newPageCount);
                library.ModifyItem(id, newBook);
                Console.WriteLine("Book modified successfully.");
            }
            else if (itemType.Equals("DVD", StringComparison.OrdinalIgnoreCase))
            {
                Console.Write("Enter new duration (in minutes): ");
                double newDuration = double.Parse(Console.ReadLine());

                var newDvd = new DVD(newTitle, newAuthor, newDuration);
                library.ModifyItem(id, newDvd);
                Console.WriteLine("DVD modified successfully.");
            }
            else
            {
                Console.WriteLine("Invalid item type.");
            }
        }

        static void DeleteItem(Library library)
        {
            Console.Write("Enter the ID of the item to delete: ");
            Guid id = Guid.Parse(Console.ReadLine());
            library.DeleteItem(id);
            Console.WriteLine("Item deleted successfully.");
        }

        static void CheckOutItem(Library library)
        {
            Console.Write("Enter the ID of the item to check out: ");
            Guid id = Guid.Parse(Console.ReadLine());
            var item = library.FindItemById(id);
            item.CheckOut();
            Console.WriteLine("Item checked out successfully.");
        }

        static void ReturnItem(Library library)
        {
            Console.Write("Enter the ID of the item to return: ");
            Guid id = Guid.Parse(Console.ReadLine());
            var item = library.FindItemById(id);
            item.Return();
            Console.WriteLine("Item returned successfully.");
        }
    }

    /*class Program
    {
        static void Main(string[] args)
        {
            string filePath = "library.csv";
            var library = new Library(filePath);

            // Add some items to the library
            var book1 = new Book("The Great Gatsby", "F. Scott Fitzgerald", 218);
            var book2 = new Book("The Great Gatsby", "F. Scott Fitzgerald", 218);
            var dvd1 = new DVD("The Matrix", "The Wachowskis", 136);

            library.AddItem(book1);
            library.AddItem(book2);
            library.AddItem(dvd1);

            // Console.ReadLine();

            Console.WriteLine("Library after adding items:");
            Console.WriteLine(library.ListItems());

            // Modify an item in the library using its GUID
            var newBook = new Book("The Great Gatsby", "F. Scott Fitzgerald", 250); // Same title but new details
            library.ModifyItem(book1.Id, newBook);

            Console.WriteLine("\nLibrary after modifying item:");
            Console.WriteLine(library.ListItems());

            // Delete an item from the library using its GUID
            library.DeleteItem(dvd1.Id);

            Console.WriteLine("\nLibrary after deleting an item:");
            Console.WriteLine(library.ListItems());

            // Check out and return a book
            book1.CheckOut();
            Console.WriteLine($"\nAfter checking out '{book1.Title}':");
            Console.WriteLine(library.ListItems());

            book1.Return();
            Console.WriteLine($"\nAfter returning '{book1.Title}':");
            Console.WriteLine(library.ListItems());
        }
    }*/
}
